package ar.com.centro8.java.curso.eleonora;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Actividad1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
